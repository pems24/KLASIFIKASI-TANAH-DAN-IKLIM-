
from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB

# Lokasi file
DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# Membaca dataset
df = pd.read_csv(DATA_PATH)
df.columns = df.columns.str.strip()

all_features = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]

target = "label"

df = df.dropna(subset=all_features + [target])

X = df[all_features]
y = df[target]

# Kelompok fitur berdasarkan hasil permutation importance awal
feature_groups = {
    "7 fitur": all_features,
    "5 fitur": [
        "humidity", "N", "rainfall", "K", "P"
    ],
    "3 fitur": [
        "humidity", "N", "rainfall"
    ]
}

# Model yang dibandingkan
def build_models():
    return {
        "Random Forest": RandomForestClassifier(
            n_estimators=200,
            random_state=42,
            n_jobs=1
        ),
        "Gaussian Naive Bayes": GaussianNB(),
        "Decision Tree": DecisionTreeClassifier(
            random_state=42
        ),
        "KNN": make_pipeline(
            StandardScaler(),
            KNeighborsClassifier(n_neighbors=5)
        ),
        "SVM": make_pipeline(
            StandardScaler(),
            SVC(kernel="rbf")
        )
    }

# Cross-validation 5 fold
cv = StratifiedKFold(
    n_splits=5,
    shuffle=True,
    random_state=42
)

scoring = {
    "accuracy": "accuracy",
    "precision_macro": "precision_macro",
    "recall_macro": "recall_macro",
    "f1_macro": "f1_macro"
}

results = []

print("=== UJI PENGURANGAN FITUR ===")
print("Jumlah data:", len(df))
print("Jumlah jenis tanaman:", y.nunique())

for group_name, selected_features in feature_groups.items():
    print(f"\nMenguji kelompok: {group_name}")
    print("Fitur:", ", ".join(selected_features))

    X_selected = X[selected_features]

    for model_name, model in build_models().items():
        print("  Menguji model:", model_name)

        scores = cross_validate(
            model,
            X_selected,
            y,
            cv=cv,
            scoring=scoring,
            n_jobs=-1,
            return_train_score=False
        )

        results.append({
            "Kelompok_fitur": group_name,
            "Jumlah_fitur": len(selected_features),
            "Algoritma": model_name,
            "Accuracy_mean": scores["test_accuracy"].mean(),
            "Accuracy_std": scores["test_accuracy"].std(),
            "Precision_macro_mean":
                scores["test_precision_macro"].mean(),
            "Recall_macro_mean":
                scores["test_recall_macro"].mean(),
            "F1_macro_mean": scores["test_f1_macro"].mean(),
            "F1_macro_std": scores["test_f1_macro"].std()
        })

# Simpan hasil ke CSV
result_df = pd.DataFrame(results)
result_df = result_df.sort_values(
    "F1_macro_mean",
    ascending=False
)

output_path = RESULTS_DIR / "hasil_pengurangan_fitur.csv"
result_df.to_csv(output_path, index=False)

print("\n=== HASIL PERBANDINGAN ===")
print(result_df.round(5).to_string(index=False))

print("\nFile hasil tersimpan di:")
print(output_path.resolve())

print("\nEksperimen selesai.")
