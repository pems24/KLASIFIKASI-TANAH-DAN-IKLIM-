
from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]


def main():
    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()
    df = df.dropna(subset=FEATURES + ["label"]).copy()

    X = df[FEATURES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_test)

    # Laporan metrik untuk setiap jenis tanaman
    report = classification_report(
        y_test, pred, output_dict=True, zero_division=0
    )
    report_df = pd.DataFrame(report).transpose()
    report_df.to_csv(
        RESULTS_DIR / "laporan_per_kelas.csv",
        index=True,
        index_label="kelas"
    )

    # Matriks kebingungan
    labels = sorted(y.unique())
    cm = confusion_matrix(y_test, pred, labels=labels)
    cm_df = pd.DataFrame(
        cm, index=labels, columns=labels
    )
    cm_df.index.name = "Label_sebenarnya"
    cm_df.columns.name = "Label_prediksi"
    cm_df.to_csv(RESULTS_DIR / "matriks_kebingungan.csv")

    # Baris yang salah diprediksi
    errors = X_test.copy()
    errors["label_sebenarnya"] = y_test
    errors["label_prediksi"] = pred
    errors = errors[
        errors["label_sebenarnya"] != errors["label_prediksi"]
    ]
    errors.to_csv(
        RESULTS_DIR / "prediksi_salah.csv", index=False
    )

    print("Jumlah data uji:", len(y_test))
    print("Jumlah prediksi salah:", len(errors))
    print("Akurasi:", round((y_test == pred).mean(), 5))
    print("\nLaporan per kelas:")
    print(classification_report(
        y_test, pred, zero_division=0
    ))
    print("\nFile tersimpan di:", RESULTS_DIR.resolve())


if __name__ == "__main__":
    main()

