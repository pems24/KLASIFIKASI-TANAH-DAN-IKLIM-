from pathlib import Path
import time

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall",
]
TARGET = "label"


def build_models():
    return {
        "Decision Tree": DecisionTreeClassifier(random_state=42),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, random_state=42, n_jobs=-1
        ),
        "KNN": make_pipeline(
            StandardScaler(), KNeighborsClassifier(n_neighbors=5)
        ),
        "SVM": make_pipeline(
            StandardScaler(), SVC(kernel="rbf")
        ),
        "Gaussian Naive Bayes": GaussianNB(),
    }


def run_cross_validation(X, y, models):
    print("\n=== STRATIFIED 5-FOLD CROSS-VALIDATION ===")

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scoring = {
        "accuracy": "accuracy",
        "precision_macro": "precision_macro",
        "recall_macro": "recall_macro",
        "f1_macro": "f1_macro",
    }

    rows = []
    for name, model in models.items():
        print(f"Menguji: {name}")
        scores = cross_validate(
            model,
            X,
            y,
            cv=cv,
            scoring=scoring,
            n_jobs=-1,
            return_train_score=False,
        )
        rows.append({
            "Algoritma": name,
            "Accuracy_mean": scores["test_accuracy"].mean(),
            "Accuracy_std": scores["test_accuracy"].std(),
            "Precision_macro_mean": scores["test_precision_macro"].mean(),
            "Recall_macro_mean": scores["test_recall_macro"].mean(),
            "F1_macro_mean": scores["test_f1_macro"].mean(),
            "F1_macro_std": scores["test_f1_macro"].std(),
        })

    result_cv = pd.DataFrame(rows).sort_values(
        "F1_macro_mean", ascending=False
    )
    output_path = RESULTS_DIR / "hasil_cross_validation.csv"
    result_cv.to_csv(output_path, index=False)

    print("\n=== HASIL CROSS-VALIDATION ===")
    print(result_cv.to_string(index=False))
    print(f"\nHasil disimpan di: {output_path.resolve()}")


def main():
    print("=== PENELITIAN REKOMENDASI TANAMAN ===")

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset tidak ditemukan: {DATA_PATH.resolve()}\n"
            "Pastikan CMD berada di folder proyek yang benar."
        )

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()

    required = FEATURES + [TARGET]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Kolom tidak ditemukan: {missing}")

    print("Ukuran dataset awal:", df.shape)
    print("\nNilai kosong per kolom:")
    print(df[required].isna().sum())
    print("\nJumlah baris duplikat:", df.duplicated().sum())

    df[FEATURES] = df[FEATURES].apply(pd.to_numeric, errors="coerce")
    df = df.dropna(subset=required).copy()

    X = df[FEATURES]
    y = df[TARGET]

    print("\nJumlah data setelah pemeriksaan:", len(df))
    print("Jumlah fitur:", len(FEATURES))
    print("Jumlah jenis tanaman:", y.nunique())

    # Eksperimen awal: satu pembagian data 80:20.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    models = build_models()
    rows = []
    predictions = {}

    for name, model in models.items():
        print(f"\nMelatih model: {name}")
        start = time.perf_counter()
        model.fit(X_train, y_train)
        elapsed = time.perf_counter() - start
        pred = model.predict(X_test)
        predictions[name] = pred

        rows.append({
            "Algoritma": name,
            "Accuracy": accuracy_score(y_test, pred),
            "Precision_macro": precision_score(
                y_test, pred, average="macro", zero_division=0
            ),
            "Recall_macro": recall_score(
                y_test, pred, average="macro", zero_division=0
            ),
            "F1_macro": f1_score(
                y_test, pred, average="macro", zero_division=0
            ),
            "Waktu_pelatihan_detik": elapsed,
        })

    result = pd.DataFrame(rows).sort_values("F1_macro", ascending=False)
    comparison_path = RESULTS_DIR / "perbandingan_algoritma.csv"
    result.to_csv(comparison_path, index=False)

    print("\n=== HASIL PERBANDINGAN ALGORITMA ===")
    print(result.to_string(index=False))

    best_name = result.iloc[0]["Algoritma"]
    best_pred = predictions[best_name]
    report = classification_report(y_test, best_pred, zero_division=0)
    (RESULTS_DIR / "laporan_klasifikasi.txt").write_text(
        report, encoding="utf-8"
    )

    labels = sorted(y.unique())
    cm = confusion_matrix(y_test, best_pred, labels=labels)
    fig, ax = plt.subplots(figsize=(13, 11))
    image = ax.imshow(cm, cmap="Blues")
    fig.colorbar(image, ax=ax)
    ax.set_title(f"Confusion Matrix - {best_name}")
    ax.set_xlabel("Prediksi")
    ax.set_ylabel("Label sebenarnya")
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=90)
    ax.set_yticklabels(labels)
    fig.tight_layout()
    fig.savefig(RESULTS_DIR / "confusion_matrix.png", dpi=200)
    plt.close(fig)

    print("\nModel dengan macro F1 tertinggi:", best_name)
    print("Hasil awal disimpan di:", RESULTS_DIR.resolve())

    # Eksperimen lanjutan dengan seluruh data dan 5 fold.
    run_cross_validation(X, y, build_models())

    print("\nEksperimen selesai.")


if __name__ == "__main__":
    main()
