
from pathlib import Path

import pandas as pd
import streamlit as st

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Konfigurasi halaman website
st.set_page_config(
    page_title="Rekomendasi Tanaman",
    page_icon="🌱",
    layout="wide"
)

# Judul website
st.title("🌱 Sistem Rekomendasi Tanaman")
st.write(
    "Masukkan kondisi tanah dan iklim untuk memperoleh "
    "prediksi jenis tanaman berdasarkan dataset."
)

DATA_PATH = Path("data/Crop_recommendation.csv")

@st.cache_resource
def train_model():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset tidak ditemukan: {DATA_PATH}"
        )

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()

    features = [
        "N", "P", "K", "temperature",
        "humidity", "ph", "rainfall"
    ]

    df = df.dropna(subset=features + ["label"])

    X = df[features]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1
    )

    model.fit(X_train, y_train)

    accuracy = accuracy_score(
        y_test, model.predict(X_test)
    )

    return model, accuracy


try:
    model, accuracy = train_model()

    st.success("Model berhasil dimuat dan dilatih.")
    
    st.subheader("📊 Pratinjau Dataset")

    data = pd.read_csv(DATA_PATH)

    st.write("Jumlah baris:", len(data))
    st.write("Jumlah jenis tanaman:", data["label"].nunique())

    st.dataframe(
    data.sample(n=20, random_state=42),
    use_container_width=True
)

    with st.expander("Lihat distribusi jumlah tanaman"):
        st.write(data["label"].value_counts())


    st.metric(
        "Akurasi evaluasi awal",
        f"{accuracy:.2%}"
    )

    st.caption(
        "Akurasi ini berasal dari satu pembagian data "
        "80:20 pada dataset, bukan jaminan hasil di lahan nyata."
    )

    st.subheader("Masukkan kondisi tanah dan iklim")

    col1, col2 = st.columns(2)

    with col1:
        nitrogen = st.number_input(
            "Nitrogen (N)", min_value=0.0,
            max_value=300.0, value=50.0
        )
        phosphorus = st.number_input(
            "Fosfor (P)", min_value=0.0,
            max_value=300.0, value=50.0
        )
        potassium = st.number_input(
            "Kalium (K)", min_value=0.0,
            max_value=300.0, value=50.0
        )
        temperature = st.number_input(
            "Suhu (°C)", min_value=-10.0,
            max_value=60.0, value=25.0
        )

    with col2:
        humidity = st.number_input(
            "Kelembapan (%)", min_value=0.0,
            max_value=100.0, value=70.0
        )
        ph = st.number_input(
            "pH tanah", min_value=0.0,
            max_value=14.0, value=6.5
        )
        rainfall = st.number_input(
            "Curah hujan (mm)", min_value=0.0,
            max_value=5000.0, value=100.0
        )

    if st.button(
        "🔍 Prediksi Tanaman",
        type="primary",
        use_container_width=True
    ):
        input_data = pd.DataFrame([{
            "N": nitrogen,
            "P": phosphorus,
            "K": potassium,
            "temperature": temperature,
            "humidity": humidity,
            "ph": ph,
            "rainfall": rainfall
        }])

        prediction = model.predict(input_data)[0]

        st.subheader("Hasil Prediksi")
        st.success(f"🌾 Tanaman yang diprediksi: {prediction}")

        st.warning(
            "Hasil ini adalah prediksi model berdasarkan dataset, "
            "bukan rekomendasi agronomi yang sudah tervalidasi "
            "untuk lokasi lahan Anda."
        )

except Exception as error:
    st.error(f"Terjadi kesalahan: {error}")
    st.info(
        "Pastikan file data/Crop_recommendation.csv tersedia "
        "di folder proyek."
    )
