
from pathlib import Path

import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline
from sklearn.metrics import make_scorer, f1_score

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]
TARGET = "label"


def main():
    print("=== VALIDASI PEMILIHAN FITUR ===")

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset tidak ditemukan: {DATA_PATH.resolve()}"
        )

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()
    df = df.dropna(subset=FEATURES + [TARGET]).copy()

    X = df[FEATURES]
    y = df[TARGET]

    cv = StratifiedKFold(
        n_splits=5,
        shuffle=True,
        random_state=42
    )

    # Semua proses pemilihan fitur berlangsung di dalam
    # setiap fold pelatihan, bukan menggunakan data validasi.
    selector_model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1
    )

    feature_selector = SelectFromModel(
        estimator=selector_model,
        threshold="median"
    )

    models = {
        "RF_7_fitur": Pipeline([
            ("model", RandomForestClassifier(
                n_estimators=200,
                random_state=42,
                n_jobs=-1
            ))
        ]),
        "RF_seleksi_fitur": Pipeline([
            ("seleksi", feature_selector),
            ("model", RandomForestClassifier(
                n_estimators=200,
                random_state=42,
                n_jobs=-1
            ))
        ])
    }

    scoring = {
        "accuracy": "accuracy",
        "precision_macro": "precision_macro",
        "recall_macro": "recall_macro",
        "f1_macro": "f1_macro"
    }

    results = []

    for name, model in models.items():
        print(f"\nMenguji: {name}")

        scores = cross_validate(
            model,
            X,
            y,
            cv=cv,
            scoring=scoring,
            n_jobs=1,
            return_train_score=False
        )

        results.append({
            "Model": name,
            "Accuracy_mean": scores["test_accuracy"].mean(),
            "Accuracy_std": scores["test_accuracy"].std(),
            "Precision_macro_mean":
                scores["test_precision_macro"].mean(),
            "Recall_macro_mean":
                scores["test_recall_macro"].mean(),
            "F1_macro_mean": scores["test_f1_macro"].mean(),
            "F1_macro_std": scores["test_f1_macro"].std()
        })

    result_df = pd.DataFrame(results)
    result_df.to_csv(
        RESULTS_DIR / "validasi_pemilihan_fitur.csv",
        index=False
    )

    print("\n=== HASIL VALIDASI 5-FOLD ===")
    print(result_df.round(5).to_string(index=False))

    print("\nHasil tersimpan di:")
    print((RESULTS_DIR / "validasi_pemilihan_fitur.csv").resolve())
    print("Eksperimen selesai.")


if __name__ == "__main__":
    main()
