
from pathlib import Path

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score, f1_score

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]


def main():
    print("=== PERMUTATION IMPORTANCE ===")

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()
    df = df.dropna(subset=FEATURES + ["label"])

    X = df[FEATURES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    pred = model.predict(X_test)
    print("Accuracy:", round(accuracy_score(y_test, pred), 4))
    print("Macro F1:", round(f1_score(
        y_test, pred, average="macro"
    ), 4))

    print("\nMenghitung permutation importance...")

    result = permutation_importance(
        model,
        X_test,
        y_test,
        scoring="f1_macro",
        n_repeats=10,
        random_state=42,
        n_jobs=-1
    )

    importance = pd.DataFrame({
        "Fitur": FEATURES,
        "Rata_rata_penurunan_F1": result.importances_mean,
        "Simpangan_baku": result.importances_std
    }).sort_values(
        "Rata_rata_penurunan_F1",
        ascending=False
    )

    importance.to_csv(
        RESULTS_DIR / "hasil_permutation_importance.csv",
        index=False
    )

    print("\n=== HASIL PERMUTATION IMPORTANCE ===")
    print(importance.to_string(index=False))

    plt.figure(figsize=(9, 5))
    plt.barh(
        importance["Fitur"],
        importance["Rata_rata_penurunan_F1"],
        xerr=importance["Simpangan_baku"]
    )
    plt.axvline(0, linewidth=1)
    plt.gca().invert_yaxis()
    plt.xlabel("Penurunan macro F1 ketika fitur diacak")
    plt.title("Permutation Importance - Random Forest")
    plt.tight_layout()
    plt.savefig(
        RESULTS_DIR / "permutation_importance.png",
        dpi=200
    )
    plt.close()

    print("\nHasil tersimpan di folder results.")


if __name__ == "__main__":
    main()
