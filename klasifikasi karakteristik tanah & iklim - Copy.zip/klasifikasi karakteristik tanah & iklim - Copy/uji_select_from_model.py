
from pathlib import Path

import pandas as pd

from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import StratifiedKFold, cross_validate
from sklearn.pipeline import Pipeline

# ==================================================
# KONFIGURASI
# ==================================================

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]
TARGET = "label"

N_SPLITS = 5
RANDOM_STATE = 42
N_ESTIMATORS = 200


def make_selector():
    """Membuat selektor fitur untuk setiap fold."""
    return SelectFromModel(
        estimator=RandomForestClassifier(
            n_estimators=N_ESTIMATORS,
            random_state=RANDOM_STATE,
            n_jobs=1
        ),
        threshold="median"
    )


def make_selected_model():
    """Seleksi fitur dan pelatihan model dalam satu pipeline."""
    return Pipeline([
        ("seleksi_fitur", make_selector()),
        ("model", RandomForestClassifier(
            n_estimators=N_ESTIMATORS,
            random_state=RANDOM_STATE,
            n_jobs=1
        ))
    ])


def main():
    print("=== ANALISIS SELECT FROM MODEL ===")

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"Dataset tidak ditemukan: {DATA_PATH.resolve()}"
        )

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()

    missing = [
        col for col in FEATURES + [TARGET]
        if col not in df.columns
    ]
    if missing:
        raise ValueError(f"Kolom tidak ditemukan: {missing}")

    df = df.dropna(subset=FEATURES + [TARGET]).copy()

    X = df[FEATURES]
    y = df[TARGET]

    print("Jumlah data:", len(df))
    print("Jumlah fitur awal:", len(FEATURES))
    print("Jumlah jenis tanaman:", y.nunique())
    print("Validasi silang:", N_SPLITS, "fold")

    cv = StratifiedKFold(
        n_splits=N_SPLITS,
        shuffle=True,
        random_state=RANDOM_STATE
    )

    scoring = {
        "accuracy": "accuracy",
        "precision_macro": "precision_macro",
        "recall_macro": "recall_macro",
        "f1_macro": "f1_macro"
    }

    # --------------------------------------------------
    # 1. PERFORMA MODEL DASAR DAN MODEL SELEKSI FITUR
    # --------------------------------------------------

    models = {
        "RF_7_fitur": RandomForestClassifier(
            n_estimators=N_ESTIMATORS,
            random_state=RANDOM_STATE,
            n_jobs=1
        ),
        "RF_SelectFromModel": make_selected_model()
    }

    performance_rows = []

    for name, model in models.items():
        print(f"\nMenguji model: {name}")

        scores = cross_validate(
            model,
            X,
            y,
            cv=cv,
            scoring=scoring,
            n_jobs=-1,
            return_train_score=False
        )

        performance_rows.append({
            "Model": name,
            "Accuracy_mean": scores["test_accuracy"].mean(),
            "Accuracy_std": scores["test_accuracy"].std(),
            "Precision_macro_mean":
                scores["test_precision_macro"].mean(),
            "Recall_macro_mean":
                scores["test_recall_macro"].mean(),
            "F1_macro_mean": scores["test_f1_macro"].mean(),
            "F1_macro_std": scores["test_f1_macro"].std()
        })

    performance_df = pd.DataFrame(performance_rows)
    performance_path = (
        RESULTS_DIR / "hasil_select_from_model.csv"
    )
    performance_df.to_csv(performance_path, index=False)

    print("\n=== PERFORMA MODEL ===")
    print(performance_df.round(5).to_string(index=False))

    # --------------------------------------------------
    # 2. FIT ULANG PADA SETIAP FOLD UNTUK MENCATAT FITUR
    # --------------------------------------------------

    fold_rows = []
    feature_rows = []

    for fold_number, (train_idx, test_idx) in enumerate(
        cv.split(X, y), start=1
    ):
        print(f"\nMemeriksa fitur pada fold {fold_number}")

        X_train = X.iloc[train_idx]
        y_train = y.iloc[train_idx]

        selector_model = make_selected_model()
        selector_model.fit(X_train, y_train)

        selector = selector_model.named_steps["seleksi_fitur"]
        support = selector.get_support()
        selected_features = [
            feature
            for feature, chosen in zip(FEATURES, support)
            if chosen
        ]

        fold_rows.append({
            "Fold": fold_number,
            "Jumlah_fitur_awal": len(FEATURES),
            "Jumlah_fitur_terpilih": len(selected_features),
            "Fitur_terpilih": ", ".join(selected_features)
        })

        for feature in FEATURES:
            feature_rows.append({
                "Fold": fold_number,
                "Fitur": feature,
                "Terpilih": int(feature in selected_features)
            })

        print("Jumlah fitur terpilih:", len(selected_features))
        print("Fitur:", ", ".join(selected_features))

    # --------------------------------------------------
    # 3. SIMPAN JUMLAH DAN DAFTAR FITUR PER FOLD
    # --------------------------------------------------

    fold_df = pd.DataFrame(fold_rows)
    fold_path = RESULTS_DIR / "fitur_terpilih_per_fold.csv"
    fold_df.to_csv(fold_path, index=False)

    # --------------------------------------------------
    # 4. HITUNG FREKUENSI PEMILIHAN SETIAP FITUR
    # --------------------------------------------------

    feature_df = pd.DataFrame(feature_rows)

    frequency_df = (
        feature_df.groupby("Fitur", as_index=False)
        .agg(
            Jumlah_fold_terpilih=("Terpilih", "sum"),
            Total_fold=("Fold", "nunique")
        )
    )

    frequency_df["Frekuensi_pemilihan_persen"] = (
        frequency_df["Jumlah_fold_terpilih"]
        / frequency_df["Total_fold"] * 100
    )

    frequency_df = frequency_df.sort_values(
        ["Jumlah_fold_terpilih", "Fitur"],
        ascending=[False, True]
    )

    frequency_path = (
        RESULTS_DIR / "frekuensi_pemilihan_fitur.csv"
    )
    frequency_df.to_csv(frequency_path, index=False)

    # --------------------------------------------------
    # 5. TAMPILKAN DAN SIMPAN RINGKASAN
    # --------------------------------------------------

    print("\n=== FITUR TERPILIH PER FOLD ===")
    print(fold_df.to_string(index=False))

    print("\n=== FREKUENSI PEMILIHAN FITUR ===")
    print(frequency_df.to_string(index=False))

    print("\nSemua hasil berhasil disimpan:")
    print(performance_path.resolve())
    print(fold_path.resolve())
    print(frequency_path.resolve())

    print("\nEksperimen selesai.")


if __name__ == "__main__":
    main()
