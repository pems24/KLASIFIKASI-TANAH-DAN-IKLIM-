
from pathlib import Path

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]


def main():
    print("=== ANALISIS STATISTIK DATA TANAMAN ===")

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()

    # Statistik deskriptif
    stats = df[FEATURES].describe().T.round(3)
    stats.to_csv(RESULTS_DIR / "statistik_deskriptif.csv")

    print("\nStatistik deskriptif:")
    print(stats.to_string())

    # Distribusi jumlah data per tanaman
    counts = df["label"].value_counts().sort_values()

    plt.figure(figsize=(10, 8))
    counts.plot(kind="barh")
    plt.title("Jumlah Data per Jenis Tanaman")
    plt.xlabel("Jumlah data")
    plt.ylabel("Jenis tanaman")
    plt.tight_layout()
    plt.savefig(
        RESULTS_DIR / "distribusi_tanaman.png",
        dpi=200
    )
    plt.close()

    # Korelasi fitur numerik
    correlation = df[FEATURES].corr()
    correlation.to_csv(RESULTS_DIR / "korelasi_fitur.csv")

    plt.figure(figsize=(10, 8))
    sns.heatmap(
        correlation,
        annot=True,
        fmt=".2f",
        cmap="coolwarm",
        vmin=-1,
        vmax=1
    )
    plt.title("Korelasi Antarfitur Tanah dan Iklim")
    plt.tight_layout()
    plt.savefig(
        RESULTS_DIR / "korelasi_fitur.png",
        dpi=200
    )
    plt.close()

    print("\nFile hasil analisis tersimpan di:")
    print(RESULTS_DIR.resolve())
    print("Analisis selesai.")


if __name__ == "__main__":
    main()
