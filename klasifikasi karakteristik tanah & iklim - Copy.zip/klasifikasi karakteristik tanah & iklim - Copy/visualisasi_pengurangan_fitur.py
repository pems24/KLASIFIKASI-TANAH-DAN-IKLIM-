
from pathlib import Path

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

RESULTS_DIR = Path("results")

input_file = RESULTS_DIR / "hasil_pengurangan_fitur.csv"
output_file = RESULTS_DIR / "grafik_pengurangan_fitur.png"

if not input_file.exists():
    raise FileNotFoundError(
        f"File hasil tidak ditemukan: {input_file}"
    )

df = pd.read_csv(input_file)

# Grafik macro F1
pivot = df.pivot(
    index="Kelompok_fitur",
    columns="Algoritma",
    values="F1_macro_mean"
)

# Urutan kelompok fitur
urutan = ["7 fitur", "5 fitur", "3 fitur"]
pivot = pivot.reindex(urutan)

ax = pivot.plot(
    kind="bar",
    figsize=(11, 6),
    rot=0
)

ax.set_title(
    "Perbandingan Macro F1 Berdasarkan Jumlah Fitur"
)
ax.set_xlabel("Kelompok fitur")
ax.set_ylabel("Macro F1 rata-rata (5-fold CV)")
ax.set_ylim(0.80, 1.01)
ax.legend(title="Algoritma")
ax.grid(axis="y", alpha=0.3)

plt.tight_layout()
plt.savefig(output_file, dpi=200)
plt.close()

print("Grafik berhasil dibuat:")
print(output_file.resolve())
