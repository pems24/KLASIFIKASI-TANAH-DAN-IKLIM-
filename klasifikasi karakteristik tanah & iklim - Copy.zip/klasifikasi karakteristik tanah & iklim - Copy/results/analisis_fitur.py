
from pathlib import Path

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

DATA_PATH = Path("data/Crop_recommendation.csv")
RESULTS_DIR = Path("results")
RESULTS_DIR.mkdir(exist_ok=True)

FEATURES = [
    "N", "P", "K", "temperature",
    "humidity", "ph", "rainfall"
]


def main():
    print("=== ANALISIS KEPENTINGAN FITUR ===")

    df = pd.read_csv(DATA_PATH)
    df.columns = df.columns.str.strip()
    df = df.dropna(subset=FEATURES + ["label"])

    X = df[FEATURES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    model = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train, y_train)

    importance = pd.DataFrame({
        "Fitur": FEATURES,
        "Kepentingan": model.feature_importances_
    }).sort_values("Kepentingan", ascending=False)

    importance.to_csv(
        RESULTS_DIR / "kepentingan_fitur.csv",
        index=False
    )

    print("\nPeringkat kepentingan fitur:")
    print(importance.to_string(index=False))

    plt.figure(figsize=(9, 5))
    plt.barh(
        importance["Fitur"],
        importance["Kepentingan"]
    )
    plt.gca().invert_yaxis()
    plt.xlabel("Kepentingan fitur")
    plt.title("Kepentingan Fitur - Random Forest")
    plt.tight_layout()
    plt.savefig(
        RESULTS_DIR / "kepentingan_fitur.png",
        dpi=200
    )
    plt.close()

    print("\nFile tersimpan di folder results.")


if __name__ == "__main__":
    main()
